#include <stdio.h>
#include <iostream>

class Stack
{
	public:

		char *stack;
		int top;
		int capacity;

	public:

		Stack(int stackCapacity = 100010)
		{

			top = -1;
			capacity = stackCapacity;
			stack = new char[capacity];
		}

		bool IsEmpty() const
		{
			return top == -1;
		}

		char& Top() const
		{ 
			if (IsEmpty()) throw "Stack is empty";
			return stack[top];
		}

		void ChangeSize1D(char*& a, const int oldSize, const int newSize)
		{
			char * temp = new char[newSize];
			int number = oldSize;
			std::copy(a, a + number, temp);
			delete[] a;
			a = temp;
		}

		void Push(const char& x)
		{
			if (top == capacity - 1)
			{
				ChangeSize1D(stack, capacity, 2 * capacity);
				capacity *= 2;
			}

			stack[++top] = x;

		}

		void Pop()
		{
			if (IsEmpty()) throw "Stack is empty. Cannot delete";
			stack[top--];
		}

};
int main(void)
{
	char pres=0;
	Stack S;
	int p=-1; // When input number is sequence , using this variable exception handle that situation.
	bool first=true;
	char before=0;

	while (1)
	{
		before = pres;

		if (scanf("%c", &pres)==EOF)
		{
			while(S.top!=-1)
			{
				printf("%c ", S.Top());
				S.Pop();
			}
			break;
		}

		if (('0' <= pres) && (pres <= '9'))
		{
			if (p == -1)
			{
				p = 0;
				p = p * 10 + pres - '0';
			}
			else
			{
				p = p * 10 + pres - '0';
			}
		}
		else if (p != -1)
		{
			printf("%d ", p);
			p = -1;
		}

		if (pres == '\n')
		{

			while (!S.IsEmpty())
			{
				printf("%c ", S.Top());
				S.Pop();
			}
			printf("\n");
			first = true;
			continue;
		}

		else if (pres == '+')
		{
			// unary 의 경우 stack 에 넣지말고 그냥 무시할것 

			if ((first == true) || (before == '+') || (before == '-') || (before == '*') || (before == '/') || (before == '('))
			{
				continue;
			}
			// binary 의 경우 보통 stack 과 같이 표현
			// 우선순위에 따라서 출력 결과 결정
			if (S.top == -1)
			{
				S.Push('+');
			}
			else if (S.Top() == '+' || S.Top() == '-' || S.Top() == '*' || S.Top() == '/')
			{
				printf("%c ", S.Top());
				S.Pop();
				S.Push('+');
			}
			else if (S.Top() == '(')
			{
				S.Push('+');
			}
		}

		else if (pres == '-')
		{
			// unary 의 경우 stack 에 넣지 말고 바로 출력할것
			if ((first == true) || (before == '+') || (before == '-') || (before == '*') || (before == '/') || (before == '('))
			{
				printf("%c", '-');
				continue;
			}
			// binary 의 경우 보통 stack 과 같이 표현
			if (S.top == -1)
			{
				S.Push('-');
			}

			else if (S.Top() == '+' || S.Top() == '-' || S.Top() == '*' || S.Top() == '/')
			{
				printf("%c ", S.Top());
				S.Pop();
				S.Push('-');
			}
			else if (S.Top() == '(')
			{
				S.Push('-');
			}

		}

		else if (pres == '/')
		{
			// 보통 stack 과 같이 표현
			if (S.top == -1)
			{
				S.Push('/');
			}
			else if (S.Top() == '+' || S.Top() == '-')
			{
				S.Push('/');
			}
			else if (S.Top() == '*' || S.Top() == '/')
			{
				printf("%c ", S.Top());
				S.Pop();
				S.Push('/');
			}
			else if (S.Top() == '(')
			{
				S.Push('/');
			}
		}

		else if (pres == '*')
		{
			// 보통 stack 과 같이 표현
			if (S.top == -1)
			{
				S.Push('*');
			}

			else if (S.Top() == '+' || S.Top() == '-')
			{
				S.Push('*');
			}
			else if (S.Top() == '*' || S.Top() == '/')
			{
				printf("%c ", S.Top());
				S.Pop();
				S.Push('*');
			}
			else if (S.Top() == '(')
			{
				S.Push('*');
			}
		}

		else if (pres == '(')
		{
			// 무조건 stack에 쌓을 것
			S.Push('(');
		}


		else if (pres == ')')
		{
			// 가장 가까운 ( 까지  pop 하고 ()는 없앨것
			while (1)
			{
				if (S.Top() == '(')
				{
					S.Pop();
					break;
				}
				else
				{
					printf("%c ", S.Top());
					S.Pop();
				}
			}
		}

		first = false;
	}

	return 0;
}
