#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>

int creat(const char *pathnmae, mode_t mode);
open(pathname, O_RDWR|O_CREAT|O_TRUNC, mode);
open(pathname, O_RDWR|O_CREAT|O_TRUNC, mode);
