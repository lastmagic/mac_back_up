#define NAMESIZE 24

struct employee
{
	char name[NAMESIZE];
	int salary;
	int pid;
};
